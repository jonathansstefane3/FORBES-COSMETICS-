FORBES' BEAUTY PARLOUR - READY TO RUN

In VS Code terminal:
1. python -m venv .venv
2. .venv\Scripts\Activate.ps1
3. pip install -r requirements.txt
4. python app.py
5. Open http://127.0.0.1:5000

The gallery uses remote Unsplash photos, so an internet connection is needed for those images.
The Fenty Beauty, Kylie Cosmetics, MAC Cosmetics and Dior Beauty sections use text-only brand names.
Use official/licensed brand assets if you have permission to publish them.
