from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime

app = Flask(__name__)
app.secret_key = "forbes-beauty-demo-key"

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        service = request.form.get("service", "").strip()
        date = request.form.get("date", "").strip()
        time = request.form.get("time", "").strip()
        if name and service and date and time:
            flash(f"Thank you, {name}! Your booking request for {service} on {date} at {time} has been received.", "success")
        else:
            flash("Please complete all required booking fields.", "error")
        return redirect(url_for("home") + "#booking")
    return render_template("index.html", year=datetime.now().year)

if __name__ == "__main__":
    app.run(debug=True)
