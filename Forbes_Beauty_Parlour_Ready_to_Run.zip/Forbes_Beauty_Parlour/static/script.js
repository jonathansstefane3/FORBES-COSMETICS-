window.addEventListener("load",()=>setTimeout(()=>{document.getElementById("loader").style.opacity="0";document.getElementById("loader").style.visibility="hidden"},900));
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("show")}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));
const menu=document.querySelector(".menu-btn"),links=document.querySelector(".nav-links");
menu.addEventListener("click",()=>links.classList.toggle("open"));
links.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>links.classList.remove("open")));
document.querySelectorAll('input[type="date"]').forEach(i=>{let d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());i.min=d.toISOString().split("T")[0]});
