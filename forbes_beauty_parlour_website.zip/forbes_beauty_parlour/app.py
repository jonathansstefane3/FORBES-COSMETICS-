from flask import Flask,render_template,request
app=Flask(__name__)
@app.route('/',methods=['GET','POST'])
def home():
    msg=''
    if request.method=='POST':
        msg='Thank you, {}! Your booking request has been received.'.format(request.form.get('name'))
    return render_template('index.html',msg=msg)
if __name__=='__main__':
    app.run(debug=True)
